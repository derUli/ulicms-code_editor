<?php
function code_editor_render() {
	return "";
}