<?php
define ( "MODULE_ADMIN_HEADLINE", get_translation ( "code_editor" ) );
define ( "MODULE_ADMIN_REQUIRED_PERMISSION", "code_editor" );
function code_editor_admin() {
	$controller = new CodeEditorController ();
	$files = $controller->getAllEditableFiles ();
	$_SESSION ["editable_code_files"] = $files;
	?>
<table class="tablesorter">
	<thead>
		<tr>
			<th>
<?php translate("file");?>
</th>
			<th>
<?php translate("last_changed");?>
</th>
			<th>
<?php translate("size");?>
</th>
			<td></td>
		</tr>
	</thead>
	<tbody>
<?php
	
	foreach ( $files as $file ) {
		$absPath = ULICMS_ROOT . $file;
		?>
<tr>
			<td style="word-break: break-all;"><?php Template::escape($file);?></td>
			<td><?php
		echo strftime ( "%x %X", filemtime ( $absPath ) );
		?></td>
			<td style="text-align: right;"><?php echo filesize($absPath) / 1024;?> KB</td>
			<td></td>
		</tr>
<?php }?>
	</tbody>
</table>
<?php
}
?>
